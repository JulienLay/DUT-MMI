/**
 * @param largeur
 * @param hauteur
 * @param tabDrones
 * @constructor Colonie
 */

class Colonie {
    constructor(largeur, hauteur, tabDrones) {
        this._largeur = largeur;
        this._hauteur = hauteur;
        this._tabDrones = tabDrones;
    }

    get largeur() {
        return this._largeur;
    }

    get hauteur() {
        return this._hauteur;
    }

    get tabDrones() {
        return this._tabDrones;
    }

    set largeur(value) {
        this._largeur = value;
    }

    set hauteur(value) {
        this._hauteur = value;
    }

    set tabDrones(value) {
        this._tabDrones = value;
    }

    supprimerDrone(nom) {
        if(this.tabDrones.find(element => element == nom)) {
            this.tabDrones.pop(element);
        }
    }

    ajouterDrone(nom) {
        if(this.tabDrones.find(element => element != nom)) {
            this.tabDrones.push(element);
        }
    }

    listeNom() {
        let noms = [];
        this.tabDrones.sort((v1,v2) => v1.nom > v2.nom ? 1 : -1);
        this.tabDrones.forEach(element => element.nom.push(noms))
        return noms;
    }

    getDeplacements(nom) {
        let tab = [];
        for (let i=0; i<this.tabDrones; i++) {
            if (this.tabDrones[i].nom == nom) {
                let calculPosition = (this.tabDrones[i].position[i+1][0] - this.tabDrones[i].position[i][0], this.tabDrones[i].position[i+1][1] - this.tabDrones[i].position[i][1]);
                tab.push(calculPosition);
            }
        }
        return tab;
    }

    getOccupation() {
        
    }
}